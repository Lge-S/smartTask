# SmartTask v1.0 — Gestión de Tareas en Consola

Aplicación de consola desarrollada en Java como parte del **Módulo 4: Fundamentos de Programación en Java**.

---

## Estructura del Proyecto

```
SmartTask/
├── pom.xml
├── src/
│   ├── main/java/smarttask/
│   │   ├── SmartTask.java                        ← Clase principal (main)
│   │   ├── interfaces/
│   │   │   └── Accionable.java                   ← Interfaz (Lección 6)
│   │   ├── model/
│   │   │   ├── Tarea.java                        ← Clase abstracta base
│   │   │   ├── TareaNormal.java                  ← Herencia (Lección 6)
│   │   │   └── TareaUrgente.java                 ← Polimorfismo (Lección 6)
│   │   └── service/
│   │       └── GestorTareas.java                 ← Lógica de negocio (Lección 5)
│   └── test/java/smarttask/
│       └── GestorTareasTest.java                 ← JUnit 5 (Lección 7)
└── docs/
```

---

## Requisitos

- Java 17 o superior (JDK)
- Maven 3.8+
- IDE: Eclipse o VSCode con extensión Java

---

## Compilar y ejecutar

```bash
# Compilar
mvn clean package -DskipTests

# Ejecutar el .jar
java -jar target/SmartTask.jar

# Ejecutar pruebas
mvn test

# Generar JavaDoc
mvn javadoc:javadoc
# → se genera en docs/javadoc/index.html
```

---

## Funcionalidades

| Opción | Función |
|--------|---------|
| 1 | Agregar tarea (Normal o Urgente) con nombre y prioridad |
| 2 | Listar: todas / activas / completadas |
| 3 | Marcar tarea como completada por ID |
| 4 | Eliminar tarea por ID |
| 5 | Ver estadísticas del sistema |
| 0 | Salir |

---

## Conceptos aplicados por lección

| Lección | Concepto | Archivo |
|---------|---------|---------|
| 3 | Tipos, operadores, estructuras de control | `Tarea.java` |
| 4 | Menú consola, Scanner, JavaDoc | `SmartTask.java` |
| 5 | Encapsulamiento, GestorTareas, métodos | `GestorTareas.java` |
| 6 | Herencia, polimorfismo, interfaz | `Tarea`, `TareaNormal`, `TareaUrgente`, `Accionable` |
| 7 | Pruebas unitarias JUnit 5, cobertura ≥80% | `GestorTareasTest.java` |

---

## Pruebas unitarias

El archivo `GestorTareasTest.java` incluye **22 pruebas** organizadas en suites anidadas (`@Nested`):

- `AgregarTareaTests` — 5 pruebas
- `ListarTareasTests` — 4 pruebas
- `MarcarCompletadaTests` — 4 pruebas
- `EliminarTareaTests` — 3 pruebas
- `EstadisticasTests` — 1 prueba
- `ModeloTareaTests` — 3 pruebas (incluyendo prueba parametrizada)

---

## Entregables

- [x] Código fuente completo (`src/`)
- [x] `pom.xml` para generar `.jar` ejecutable
- [x] JavaDoc en todas las clases y métodos públicos
- [x] Suite de pruebas JUnit 5 con cobertura ≥80%
