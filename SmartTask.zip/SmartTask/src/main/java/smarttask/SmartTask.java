package smarttask;

import smarttask.model.Tarea;
import smarttask.model.Tarea.Prioridad;
import smarttask.service.GestorTareas;

import java.util.List;
import java.util.Scanner;

/**
 * Clase principal de la aplicación SmartTask.
 *
 * <p>Implementa el menú interactivo de consola y coordina la interacción
 * entre el usuario y el {@link GestorTareas}. Sigue el principio de bajo
 * acoplamiento: la lógica de negocio reside en GestorTareas, mientras que
 * esta clase se ocupa exclusivamente de la presentación y la entrada de datos.</p>
 *
 * <p><b>Instrucciones de uso:</b></p>
 * <pre>
 *   java -jar SmartTask.jar
 * </pre>
 *
 * @author SmartTask
 * @version 1.0
 */
public class SmartTask {

    /** Instancia del gestor de tareas (lógica de negocio). */
    private static final GestorTareas gestor = new GestorTareas();

    /** Scanner global para lectura de entrada del usuario. */
    private static final Scanner scanner = new Scanner(System.in);

    // ─── Punto de entrada ──────────────────────────────────────────────────

    /**
     * Método principal. Inicia la aplicación SmartTask.
     *
     * @param args argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        mostrarBienvenida();
        boolean ejecutando = true;

        while (ejecutando) {
            mostrarMenu();
            int opcion = leerEnteroSeguro("Selecciona una opción: ");

            switch (opcion) {
                case 1 -> agregarTareaInteractivo();
                case 2 -> listarTareas();
                case 3 -> marcarCompletada();
                case 4 -> eliminarTarea();
                case 5 -> mostrarEstadisticas();
                case 0 -> {
                    ejecutando = false;
                    System.out.println("\n¡Hasta luego! 👋  Saliendo de SmartTask...\n");
                }
                default -> System.out.println("⚠  Opción no válida. Intenta de nuevo.\n");
            }
        }

        scanner.close();
    }

    // ─── Métodos de presentación ───────────────────────────────────────────

    /**
     * Muestra el banner de bienvenida al iniciar la aplicación.
     */
    private static void mostrarBienvenida() {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║         SmartTask v1.0 - Consola         ║");
        System.out.println("║   Gestión inteligente de tus tareas 📋   ║");
        System.out.println("╚══════════════════════════════════════════╝");
        System.out.println();
    }

    /**
     * Imprime el menú principal con todas las opciones disponibles.
     */
    private static void mostrarMenu() {
        System.out.println("─────────────────────────────────────────");
        System.out.println("  MENÚ PRINCIPAL");
        System.out.println("─────────────────────────────────────────");
        System.out.println("  1. ➕  Agregar tarea");
        System.out.println("  2. 📋  Listar tareas");
        System.out.println("  3. ✅  Marcar tarea como completada");
        System.out.println("  4. 🗑   Eliminar tarea");
        System.out.println("  5. 📊  Ver estadísticas");
        System.out.println("  0. 🚪  Salir");
        System.out.println("─────────────────────────────────────────");
    }

    // ─── Opciones del menú ─────────────────────────────────────────────────

    /**
     * Flujo interactivo para agregar una nueva tarea.
     * Permite elegir entre tarea normal y tarea urgente.
     */
    private static void agregarTareaInteractivo() {
        System.out.println("\n── AGREGAR TAREA ──────────────────────");

        System.out.print("Nombre de la tarea: ");
        String nombre = scanner.nextLine().trim();
        if (nombre.isEmpty()) {
            System.out.println("⚠  El nombre no puede estar vacío.\n");
            return;
        }

        Prioridad prioridad = seleccionarPrioridad();
        if (prioridad == null) return;

        System.out.println("Tipo de tarea:");
        System.out.println("  1. Normal");
        System.out.println("  2. Urgente");
        int tipo = leerEnteroSeguro("Selecciona (1-2): ");

        Tarea nueva;
        switch (tipo) {
            case 1 -> {
                nueva = gestor.agregarTarea(nombre, prioridad);
                System.out.printf("%n✅  Tarea normal creada con ID %d.%n%n", nueva.getId());
            }
            case 2 -> {
                System.out.print("Mensaje de alerta (Enter para predeterminado): ");
                String alerta = scanner.nextLine().trim();
                nueva = gestor.agregarTareaUrgente(nombre, prioridad,
                        alerta.isEmpty() ? null : alerta);
                System.out.printf("%n⚠   Tarea urgente creada con ID %d.%n%n", nueva.getId());
            }
            default -> {
                System.out.println("⚠  Tipo no válido.\n");
                return;
            }
        }
    }

    /**
     * Muestra la lista de tareas según el filtro elegido por el usuario.
     */
    private static void listarTareas() {
        System.out.println("\n── LISTAR TAREAS ──────────────────────");
        System.out.println("  1. Todas");
        System.out.println("  2. Solo activas (pendientes)");
        System.out.println("  3. Solo completadas");
        int filtro = leerEnteroSeguro("Selecciona (1-3): ");

        List<Tarea> lista;
        String titulo;

        switch (filtro) {
            case 1 -> { lista = gestor.listarTareas();           titulo = "TODAS LAS TAREAS"; }
            case 2 -> { lista = gestor.listarTareasActivas();    titulo = "TAREAS ACTIVAS";   }
            case 3 -> { lista = gestor.listarTareasCompletadas(); titulo = "TAREAS COMPLETADAS"; }
            default -> {
                System.out.println("⚠  Opción no válida.\n");
                return;
            }
        }

        System.out.println("\n── " + titulo + " ─────────────────────────────");
        if (lista.isEmpty()) {
            System.out.println("  (No hay tareas en esta categoría)");
        } else {
            lista.forEach(t -> System.out.println("  " + t));
        }
        System.out.println();
    }

    /**
     * Flujo interactivo para marcar una tarea como completada.
     */
    private static void marcarCompletada() {
        System.out.println("\n── MARCAR COMO COMPLETADA ─────────────");
        int id = leerEnteroSeguro("ID de la tarea a completar: ");

        if (gestor.marcarComoCompletada(id)) {
            System.out.printf("✅  Tarea ID %d marcada como completada.%n%n", id);
        } else {
            System.out.printf("⚠  No se encontró la tarea con ID %d.%n%n", id);
        }
    }

    /**
     * Flujo interactivo para eliminar una tarea por su ID.
     */
    private static void eliminarTarea() {
        System.out.println("\n── ELIMINAR TAREA ─────────────────────");
        int id = leerEnteroSeguro("ID de la tarea a eliminar: ");

        System.out.printf("¿Confirmas eliminar la tarea ID %d? (s/n): ", id);
        String confirm = scanner.nextLine().trim().toLowerCase();

        if (confirm.equals("s") || confirm.equals("si") || confirm.equals("sí")) {
            if (gestor.eliminarTarea(id)) {
                System.out.printf("🗑  Tarea ID %d eliminada correctamente.%n%n", id);
            } else {
                System.out.printf("⚠  No se encontró la tarea con ID %d.%n%n", id);
            }
        } else {
            System.out.println("Operación cancelada.\n");
        }
    }

    /**
     * Muestra las estadísticas generales del sistema de tareas.
     */
    private static void mostrarEstadisticas() {
        System.out.println("\n── ESTADÍSTICAS ───────────────────────");
        System.out.printf("  Total de tareas    : %d%n", gestor.totalTareas());
        System.out.printf("  Pendientes         : %d%n", gestor.totalPendientes());
        System.out.printf("  Completadas        : %d%n", gestor.totalCompletadas());
        System.out.println();
    }

    // ─── Utilidades de entrada ─────────────────────────────────────────────

    /**
     * Solicita al usuario que elija un nivel de prioridad.
     *
     * @return {@link Prioridad} seleccionada, o {@code null} si la opción es inválida
     */
    private static Prioridad seleccionarPrioridad() {
        System.out.println("Prioridad:");
        System.out.println("  1. BAJA");
        System.out.println("  2. MEDIA");
        System.out.println("  3. ALTA");
        int opcion = leerEnteroSeguro("Selecciona (1-3): ");

        return switch (opcion) {
            case 1 -> Prioridad.BAJA;
            case 2 -> Prioridad.MEDIA;
            case 3 -> Prioridad.ALTA;
            default -> {
                System.out.println("⚠  Prioridad no válida.\n");
                yield null;
            }
        };
    }

    /**
     * Lee un entero de la consola de forma segura, evitando {@link java.util.InputMismatchException}.
     *
     * @param mensaje mensaje a mostrar antes de leer
     * @return entero ingresado por el usuario, o -1 en caso de entrada inválida
     */
    private static int leerEnteroSeguro(String mensaje) {
        System.out.print(mensaje);
        try {
            int valor = Integer.parseInt(scanner.nextLine().trim());
            return valor;
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
