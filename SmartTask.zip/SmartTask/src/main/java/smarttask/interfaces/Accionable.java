package smarttask.interfaces;

/**
 * Interfaz que define las operaciones comunes para las tareas del sistema SmartTask.
 * Implementa el principio de segregación de interfaces (ISP).
 *
 * @author SmartTask
 * @version 1.0
 */
public interface Accionable {

    /**
     * Ejecuta la acción principal de la tarea.
     */
    void ejecutar();

    /**
     * Cancela o revierte la acción de la tarea.
     */
    void cancelar();

    /**
     * Retorna una descripción detallada de la tarea.
     *
     * @return descripción de la tarea como String
     */
    String obtenerDescripcion();
}
