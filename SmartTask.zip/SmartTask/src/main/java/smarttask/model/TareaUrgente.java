package smarttask.model;

/**
 * Representa una tarea urgente que requiere atención inmediata.
 * Extiende {@link Tarea} con comportamiento polimórfico diferenciado.
 *
 * <p>Al ejecutar una tarea urgente se imprime una alerta adicional en consola.</p>
 *
 * @author SmartTask
 * @version 1.0
 */
public class TareaUrgente extends Tarea {

    /** Mensaje de alerta que se mostrará al ejecutar la tarea. */
    private String mensajeAlerta;

    /**
     * Constructor de TareaUrgente.
     *
     * @param nombre         nombre de la tarea
     * @param prioridad      nivel de prioridad
     * @param mensajeAlerta  mensaje de alerta específico
     */
    public TareaUrgente(String nombre, Prioridad prioridad, String mensajeAlerta) {
        super(nombre, prioridad);
        this.mensajeAlerta = (mensajeAlerta != null && !mensajeAlerta.trim().isEmpty())
                ? mensajeAlerta.trim()
                : "¡Atención inmediata requerida!";
    }

    /**
     * Constructor simplificado con mensaje de alerta predeterminado.
     *
     * @param nombre    nombre de la tarea
     * @param prioridad nivel de prioridad
     */
    public TareaUrgente(String nombre, Prioridad prioridad) {
        this(nombre, prioridad, "¡Atención inmediata requerida!");
    }

    /**
     * Retorna el mensaje de alerta de la tarea urgente.
     *
     * @return mensaje de alerta
     */
    public String getMensajeAlerta() {
        return mensajeAlerta;
    }

    /**
     * Establece un nuevo mensaje de alerta.
     *
     * @param mensajeAlerta nuevo mensaje
     */
    public void setMensajeAlerta(String mensajeAlerta) {
        this.mensajeAlerta = mensajeAlerta;
    }

    /**
     * Sobreescribe ejecutar() para mostrar alerta antes de completar.
     * Ejemplo de polimorfismo en acción.
     */
    @Override
    public void ejecutar() {
        System.out.println("⚠ ALERTA: " + mensajeAlerta);
        super.ejecutar();
    }

    /**
     * Retorna la descripción con indicador de urgencia.
     *
     * @return descripción del tipo de tarea
     */
    @Override
    public String obtenerDescripcion() {
        return "Tipo: URGENTE ⚠";
    }
}
