package smarttask.model;

import smarttask.interfaces.Accionable;

/**
 * Clase abstracta que representa una tarea en el sistema SmartTask.
 * Aplica encapsulamiento y sirve como base para TareaNormal y TareaUrgente.
 *
 * <p>Cada tarea posee un identificador único, nombre, prioridad y estado de completitud.</p>
 *
 * @author SmartTask
 * @version 1.0
 */
public abstract class Tarea implements Accionable {

    /** Niveles de prioridad disponibles para una tarea. */
    public enum Prioridad {
        BAJA, MEDIA, ALTA
    }

    /** Contador estático para generar IDs únicos automáticamente. */
    private static int contadorId = 1;

    /** Identificador único de la tarea. */
    private final int id;

    /** Nombre descriptivo de la tarea. */
    private String nombre;

    /** Nivel de prioridad asignado a la tarea. */
    private Prioridad prioridad;

    /** Indica si la tarea ha sido completada. */
    private boolean completado;

    /**
     * Constructor de la clase Tarea.
     *
     * @param nombre    nombre de la tarea (no puede ser nulo ni vacío)
     * @param prioridad nivel de prioridad de la tarea
     * @throws IllegalArgumentException si el nombre es nulo o vacío
     */
    public Tarea(String nombre, Prioridad prioridad) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la tarea no puede ser nulo o vacío.");
        }
        this.id = contadorId++;
        this.nombre = nombre.trim();
        this.prioridad = prioridad;
        this.completado = false;
    }

    // ─── Getters ───────────────────────────────────────────────────────────

    /**
     * Retorna el identificador único de la tarea.
     *
     * @return ID de la tarea
     */
    public int getId() {
        return id;
    }

    /**
     * Retorna el nombre de la tarea.
     *
     * @return nombre de la tarea
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Retorna el nivel de prioridad de la tarea.
     *
     * @return prioridad de la tarea
     */
    public Prioridad getPrioridad() {
        return prioridad;
    }

    /**
     * Indica si la tarea fue completada.
     *
     * @return {@code true} si la tarea está completada, {@code false} en caso contrario
     */
    public boolean isCompletado() {
        return completado;
    }

    // ─── Setters ───────────────────────────────────────────────────────────

    /**
     * Establece el nombre de la tarea.
     *
     * @param nombre nuevo nombre (no puede ser nulo ni vacío)
     * @throws IllegalArgumentException si el nombre es inválido
     */
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser vacío.");
        }
        this.nombre = nombre.trim();
    }

    /**
     * Establece la prioridad de la tarea.
     *
     * @param prioridad nuevo nivel de prioridad
     */
    public void setPrioridad(Prioridad prioridad) {
        this.prioridad = prioridad;
    }

    /**
     * Establece el estado de completitud de la tarea.
     *
     * @param completado {@code true} para marcar como completada
     */
    public void setCompletado(boolean completado) {
        this.completado = completado;
    }

    // ─── Implementación de Accionable ──────────────────────────────────────

    /**
     * Marca la tarea como completada (ejecutar = completar).
     */
    @Override
    public void ejecutar() {
        this.completado = true;
    }

    /**
     * Revierte la tarea a estado pendiente.
     */
    @Override
    public void cancelar() {
        this.completado = false;
    }

    /**
     * Método abstracto que retorna la descripción específica de cada tipo de tarea.
     *
     * @return descripción detallada
     */
    @Override
    public abstract String obtenerDescripcion();

    /**
     * Representación en texto de la tarea para mostrar en consola.
     *
     * @return String con formato legible
     */
    @Override
    public String toString() {
        String estado = completado ? "[✓]" : "[ ]";
        return String.format("%s ID:%-3d | %-30s | Prioridad: %-5s | %s",
                estado, id, nombre, prioridad, obtenerDescripcion());
    }

    /**
     * Reinicia el contador de IDs (solo para uso en pruebas unitarias).
     */
    public static void reiniciarContador() {
        contadorId = 1;
    }
}
