package smarttask.model;

/**
 * Representa una tarea estándar sin características especiales.
 * Hereda de {@link Tarea} e implementa {@link smarttask.interfaces.Accionable}.
 *
 * @author SmartTask
 * @version 1.0
 */
public class TareaNormal extends Tarea {

    /**
     * Constructor de TareaNormal.
     *
     * @param nombre    nombre de la tarea
     * @param prioridad nivel de prioridad
     */
    public TareaNormal(String nombre, Prioridad prioridad) {
        super(nombre, prioridad);
    }

    /**
     * Retorna la descripción específica de una tarea normal.
     *
     * @return descripción del tipo de tarea
     */
    @Override
    public String obtenerDescripcion() {
        return "Tipo: Normal";
    }
}
