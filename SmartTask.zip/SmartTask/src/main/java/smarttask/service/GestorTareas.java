package smarttask.service;

import smarttask.model.Tarea;
import smarttask.model.TareaNormal;
import smarttask.model.TareaUrgente;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Gestor central de tareas del sistema SmartTask.
 *
 * <p>Aplica el principio de responsabilidad única (SRP): esta clase se encarga
 * exclusivamente de la lógica de negocio relacionada con las tareas
 * (agregar, listar, completar, eliminar).</p>
 *
 * @author SmartTask
 * @version 1.0
 */
public class GestorTareas {

    /** Lista interna que almacena todas las tareas del sistema. */
    private final List<Tarea> tareas;

    /**
     * Constructor que inicializa la lista de tareas vacía.
     */
    public GestorTareas() {
        this.tareas = new ArrayList<>();
    }

    // ─── Agregar ───────────────────────────────────────────────────────────

    /**
     * Agrega una nueva tarea normal al sistema.
     *
     * @param nombre    nombre de la tarea
     * @param prioridad nivel de prioridad
     * @return la tarea recién creada
     * @throws IllegalArgumentException si el nombre es inválido
     */
    public Tarea agregarTarea(String nombre, Tarea.Prioridad prioridad) {
        TareaNormal tarea = new TareaNormal(nombre, prioridad);
        tareas.add(tarea);
        return tarea;
    }

    /**
     * Agrega una nueva tarea urgente al sistema.
     *
     * @param nombre         nombre de la tarea
     * @param prioridad      nivel de prioridad
     * @param mensajeAlerta  alerta específica para la tarea urgente
     * @return la tarea urgente recién creada
     */
    public Tarea agregarTareaUrgente(String nombre, Tarea.Prioridad prioridad, String mensajeAlerta) {
        TareaUrgente tarea = new TareaUrgente(nombre, prioridad, mensajeAlerta);
        tareas.add(tarea);
        return tarea;
    }

    // ─── Listar ────────────────────────────────────────────────────────────

    /**
     * Retorna una copia de la lista con todas las tareas registradas.
     *
     * @return lista de todas las tareas
     */
    public List<Tarea> listarTareas() {
        return new ArrayList<>(tareas);
    }

    /**
     * Retorna solo las tareas que están pendientes (no completadas).
     *
     * @return lista de tareas activas
     */
    public List<Tarea> listarTareasActivas() {
        return tareas.stream()
                .filter(t -> !t.isCompletado())
                .collect(Collectors.toList());
    }

    /**
     * Retorna solo las tareas que han sido completadas.
     *
     * @return lista de tareas completadas
     */
    public List<Tarea> listarTareasCompletadas() {
        return tareas.stream()
                .filter(Tarea::isCompletado)
                .collect(Collectors.toList());
    }

    // ─── Buscar ────────────────────────────────────────────────────────────

    /**
     * Busca una tarea por su ID único.
     *
     * @param id identificador de la tarea
     * @return {@link Optional} con la tarea si existe, vacío si no
     */
    public Optional<Tarea> buscarPorId(int id) {
        return tareas.stream()
                .filter(t -> t.getId() == id)
                .findFirst();
    }

    // ─── Completar ─────────────────────────────────────────────────────────

    /**
     * Marca una tarea como completada dado su ID.
     * Invoca el método polimórfico {@code ejecutar()} de cada tipo de tarea.
     *
     * @param id identificador de la tarea a completar
     * @return {@code true} si la tarea fue encontrada y completada, {@code false} si no existe
     */
    public boolean marcarComoCompletada(int id) {
        Optional<Tarea> tarea = buscarPorId(id);
        tarea.ifPresent(Tarea::ejecutar);
        return tarea.isPresent();
    }

    // ─── Eliminar ──────────────────────────────────────────────────────────

    /**
     * Elimina una tarea del sistema por su ID.
     *
     * @param id identificador de la tarea a eliminar
     * @return {@code true} si la tarea fue encontrada y eliminada, {@code false} si no existe
     */
    public boolean eliminarTarea(int id) {
        return tareas.removeIf(t -> t.getId() == id);
    }

    // ─── Estadísticas ──────────────────────────────────────────────────────

    /**
     * Retorna el total de tareas registradas en el sistema.
     *
     * @return cantidad total de tareas
     */
    public int totalTareas() {
        return tareas.size();
    }

    /**
     * Retorna el total de tareas pendientes.
     *
     * @return cantidad de tareas no completadas
     */
    public int totalPendientes() {
        return (int) tareas.stream().filter(t -> !t.isCompletado()).count();
    }

    /**
     * Retorna el total de tareas completadas.
     *
     * @return cantidad de tareas completadas
     */
    public int totalCompletadas() {
        return (int) tareas.stream().filter(Tarea::isCompletado).count();
    }
}
