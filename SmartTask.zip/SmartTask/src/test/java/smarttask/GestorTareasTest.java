package smarttask;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import smarttask.model.Tarea;
import smarttask.model.Tarea.Prioridad;
import smarttask.model.TareaNormal;
import smarttask.model.TareaUrgente;
import smarttask.service.GestorTareas;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Suite de pruebas unitarias para el sistema SmartTask.
 *
 * <p>Cubre las funcionalidades principales de {@link GestorTareas} y los modelos
 * {@link TareaNormal} y {@link TareaUrgente}. Objetivo: cobertura mínima del 80%.</p>
 *
 * @author SmartTask
 * @version 1.0
 */
@DisplayName("Suite de pruebas SmartTask")
class GestorTareasTest {

    private GestorTareas gestor;

    /**
     * Reinicia el gestor y el contador de IDs antes de cada prueba
     * para garantizar independencia entre tests.
     */
    @BeforeEach
    void setUp() {
        Tarea.reiniciarContador();
        gestor = new GestorTareas();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRUEBAS: agregarTarea
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("agregarTarea()")
    class AgregarTareaTests {

        @Test
        @DisplayName("Debe agregar una tarea normal y retornarla")
        void debeAgregarTareaNormal() {
            Tarea t = gestor.agregarTarea("Estudiar Java", Prioridad.MEDIA);

            assertNotNull(t);
            assertEquals("Estudiar Java", t.getNombre());
            assertEquals(Prioridad.MEDIA, t.getPrioridad());
            assertFalse(t.isCompletado());
            assertEquals(1, gestor.totalTareas());
        }

        @Test
        @DisplayName("Debe asignar IDs únicos a cada tarea")
        void debeAsignarIdsUnicos() {
            Tarea t1 = gestor.agregarTarea("Tarea 1", Prioridad.BAJA);
            Tarea t2 = gestor.agregarTarea("Tarea 2", Prioridad.ALTA);

            assertNotEquals(t1.getId(), t2.getId());
        }

        @Test
        @DisplayName("Debe lanzar excepción si el nombre es nulo")
        void debeLanzarExcepcionNombreNulo() {
            assertThrows(IllegalArgumentException.class,
                    () -> gestor.agregarTarea(null, Prioridad.BAJA));
        }

        @Test
        @DisplayName("Debe lanzar excepción si el nombre está vacío")
        void debeLanzarExcepcionNombreVacio() {
            assertThrows(IllegalArgumentException.class,
                    () -> gestor.agregarTarea("   ", Prioridad.MEDIA));
        }

        @Test
        @DisplayName("Debe agregar tarea urgente con mensaje de alerta")
        void debeAgregarTareaUrgente() {
            Tarea t = gestor.agregarTareaUrgente("Deploy en producción", Prioridad.ALTA, "Revisar logs");

            assertNotNull(t);
            assertInstanceOf(TareaUrgente.class, t);
            assertEquals("Deploy en producción", t.getNombre());
        }

        @Test
        @DisplayName("Debe acumular múltiples tareas correctamente")
        void debeAcumularMultiplesTareas() {
            gestor.agregarTarea("T1", Prioridad.BAJA);
            gestor.agregarTarea("T2", Prioridad.MEDIA);
            gestor.agregarTarea("T3", Prioridad.ALTA);

            assertEquals(3, gestor.totalTareas());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRUEBAS: listarTareas
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("listarTareas()")
    class ListarTareasTests {

        @Test
        @DisplayName("Lista vacía cuando no hay tareas")
        void debeRetornarListaVacia() {
            assertTrue(gestor.listarTareas().isEmpty());
        }

        @Test
        @DisplayName("Debe listar todas las tareas agregadas")
        void debeListarTodasLasTareas() {
            gestor.agregarTarea("A", Prioridad.BAJA);
            gestor.agregarTarea("B", Prioridad.ALTA);

            List<Tarea> lista = gestor.listarTareas();
            assertEquals(2, lista.size());
        }

        @Test
        @DisplayName("Debe separar tareas activas de completadas")
        void debeSepararActivasDeCompletadas() {
            gestor.agregarTarea("Activa 1", Prioridad.BAJA);
            gestor.agregarTarea("Activa 2", Prioridad.MEDIA);
            Tarea completada = gestor.agregarTarea("Completada", Prioridad.ALTA);
            gestor.marcarComoCompletada(completada.getId());

            assertEquals(2, gestor.listarTareasActivas().size());
            assertEquals(1, gestor.listarTareasCompletadas().size());
        }

        @Test
        @DisplayName("listarTareas() debe retornar copia defensiva")
        void debeRetornarCopiaDefensiva() {
            gestor.agregarTarea("T", Prioridad.MEDIA);
            List<Tarea> lista = gestor.listarTareas();
            lista.clear();

            assertEquals(1, gestor.totalTareas());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRUEBAS: marcarComoCompletada
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("marcarComoCompletada()")
    class MarcarCompletadaTests {

        @Test
        @DisplayName("Debe marcar tarea existente como completada")
        void debeMarcarTareaCompletada() {
            Tarea t = gestor.agregarTarea("Revisar PR", Prioridad.ALTA);

            boolean resultado = gestor.marcarComoCompletada(t.getId());

            assertTrue(resultado);
            assertTrue(t.isCompletado());
        }

        @Test
        @DisplayName("Debe retornar false para ID inexistente")
        void debeRetornarFalseSiIdNoExiste() {
            boolean resultado = gestor.marcarComoCompletada(999);

            assertFalse(resultado);
        }

        @Test
        @DisplayName("Tarea urgente debe activar comportamiento polimórfico")
        void tareaUrgenteDebeEjecutarPolimorficamente() {
            gestor.agregarTareaUrgente("Fix crítico", Prioridad.ALTA, "Revisar logs");
            Tarea t = gestor.listarTareas().get(0);

            gestor.marcarComoCompletada(t.getId());

            assertTrue(t.isCompletado());
        }

        @Test
        @DisplayName("Cancelar debe revertir la tarea a pendiente")
        void cancelarDebeRevertirEstado() {
            Tarea t = gestor.agregarTarea("Tarea", Prioridad.MEDIA);
            t.ejecutar();
            assertTrue(t.isCompletado());

            t.cancelar();
            assertFalse(t.isCompletado());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRUEBAS: eliminarTarea
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("eliminarTarea()")
    class EliminarTareaTests {

        @Test
        @DisplayName("Debe eliminar tarea existente")
        void debeEliminarTareaExistente() {
            Tarea t = gestor.agregarTarea("Tarea a eliminar", Prioridad.BAJA);

            boolean resultado = gestor.eliminarTarea(t.getId());

            assertTrue(resultado);
            assertEquals(0, gestor.totalTareas());
        }

        @Test
        @DisplayName("Debe retornar false al eliminar ID inexistente")
        void debeRetornarFalseEliminarInexistente() {
            boolean resultado = gestor.eliminarTarea(404);

            assertFalse(resultado);
        }

        @Test
        @DisplayName("No debe afectar otras tareas al eliminar una")
        void noDebeAfectarOtrasTareas() {
            gestor.agregarTarea("T1", Prioridad.BAJA);
            Tarea t2 = gestor.agregarTarea("T2", Prioridad.MEDIA);
            gestor.agregarTarea("T3", Prioridad.ALTA);

            gestor.eliminarTarea(t2.getId());

            assertEquals(2, gestor.totalTareas());
            assertTrue(gestor.buscarPorId(t2.getId()).isEmpty());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRUEBAS: estadísticas
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Estadísticas del gestor")
    class EstadisticasTests {

        @Test
        @DisplayName("totalPendientes debe descontar las completadas")
        void totalPendientesDebeSerCorrecto() {
            gestor.agregarTarea("P1", Prioridad.BAJA);
            gestor.agregarTarea("P2", Prioridad.MEDIA);
            Tarea c = gestor.agregarTarea("C1", Prioridad.ALTA);
            gestor.marcarComoCompletada(c.getId());

            assertEquals(2, gestor.totalPendientes());
            assertEquals(1, gestor.totalCompletadas());
            assertEquals(3, gestor.totalTareas());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRUEBAS: modelo Tarea
    // ═══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Modelo Tarea")
    class ModeloTareaTests {

        @Test
        @DisplayName("toString debe incluir ID, nombre y prioridad")
        void toStringShouldContainKeyInfo() {
            Tarea t = new TareaNormal("Mi tarea", Prioridad.ALTA);
            String str = t.toString();

            assertTrue(str.contains("Mi tarea"));
            assertTrue(str.contains("ALTA"));
        }

        @Test
        @DisplayName("TareaUrgente debe tener mensaje de alerta predeterminado si no se provee")
        void tareaUrgenteDebeTenerAlertaPorDefecto() {
            TareaUrgente t = new TareaUrgente("Urgente", Prioridad.ALTA);

            assertFalse(t.getMensajeAlerta().isEmpty());
        }

        @ParameterizedTest
        @ValueSource(strings = {"", "  ", "\t"})
        @DisplayName("Debe rechazar nombres en blanco")
        void debeRechazarNombresEnBlanco(String nombre) {
            assertThrows(IllegalArgumentException.class,
                    () -> new TareaNormal(nombre, Prioridad.BAJA));
        }
    }
}
